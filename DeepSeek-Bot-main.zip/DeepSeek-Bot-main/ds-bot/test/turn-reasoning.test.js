import test from 'node:test'
import assert from 'node:assert/strict'
import { thinkingStep, turnReasoning } from '../src/client/turn-reasoning.js'

const step = (n, blocks, status = 'settled') => ({ turn: 1, step: n, status, blocks })
const think = text => ({ kind: 'reasoning', text })
const tool = { kind: 'tool-call', name: 'read' }

test('a long tool Turn shows its reasoning once, on the last step, in order', () => {
  const steps = Array.from({ length: 24 }, (_, i) => step(i + 1, [think(`Reasoning ${i + 1}`), tool]))
  const shown = steps.map(current => turnReasoning(steps, current))
  assert.equal(shown.filter(Boolean).length, 1)
  assert.equal(shown[23], steps.map((_, i) => `Reasoning ${i + 1}`).join('\n\n'))
})

test('the row sits on the last step with reasoning, next to the reply', () => {
  const steps = [step(1, [{ kind: 'text', text: 'Looking' }, tool]), step(2, [think('B'), tool]), step(3, [think('C'), { kind: 'text', text: 'Done' }])]
  assert.deepEqual(steps.map(current => turnReasoning(steps, current)), ['', '', 'B\n\nC'])
  // A Turn whose only reasoning step came first keeps the row there.
  const early = [step(1, [think('B'), tool]), step(2, [tool]), step(3, [{ kind: 'text', text: 'Done' }])]
  assert.deepEqual(early.map(current => turnReasoning(early, current)), ['B', '', ''])
})

test('reasoning still in progress shows while its step thinks', () => {
  const steps = [step(1, [think('A'), tool]), step(2, [think('B')], 'running')]
  assert.equal(turnReasoning(steps, steps[0]), '')
  assert.equal(turnReasoning(steps, steps[1]), 'A\n\nB')
  assert.equal(turnReasoning([step(1, [think('A')], 'running')], step(1, [think('A')], 'running')), 'A')
  steps[1].blocks.push({ kind: 'text', text: 'Reply' })
  assert.equal(turnReasoning(steps, steps[1]), 'A\n\nB')
})

test('the live step is the one still thinking', () => {
  const steps = [step(1, [think('A'), tool]), step(2, [think('B')], 'running')]
  assert.equal(thinkingStep(steps), steps[1])
  // Reasoning that moved on to its reply no longer ticks.
  steps[1].blocks.push({ kind: 'text', text: 'Reply' })
  assert.equal(thinkingStep(steps), undefined)
  // A running step without reasoning yet is not thinking either.
  assert.equal(thinkingStep([step(3, [tool], 'running')]), undefined)
  assert.equal(thinkingStep(steps.slice(0, 1)), undefined)
})

test('a step outside the loaded Turn list shows only its own reasoning', () => {
  const current = step(1, [think(' A ')])
  assert.equal(turnReasoning([], current), 'A')
})
